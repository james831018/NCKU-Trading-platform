<html>
<head>
<title>PHP Form Password</title>
</head>
<body>
<?php
session_start();
$host="localhost";
$username="root";  
$password="";
$database="customer";

mysql_connect($host,$username,$password);
mysql_select_db($database)or die( "Unable to select database");

$person=$_POST['account'];
//echo "person is ".$person."<br>";
$query = "SELECT account,password FROM user";
$result = mysql_query($query);

while ($row = mysql_fetch_array($result)) {
    //echo  "$row[account]<BR>\n";
    if($row['account']==$person)
    {
    	if($_POST['password']==$row['password'])
    	{
    		$_SESSION['name'] = $row['account'];
    		$url = "shop.php";
			echo "<script type='text/javascript'>";
			echo "window.location.href='$url'";
			echo "</script>"; 
    	}  	
    }
}
echo "Login Failed<br>";
?>
</body>