<DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body>

<?php
session_start();
echo "<h2>welcome:".$_SESSION['name']."</h2>";
$_SESSION['name']=$_SESSION['name'];

?>
<form action="result.php" method="post">
  item:<br>
  <input type="text" name="item">
  <br>
  price:<br>
  <input type="text" name="price">
  <br>
  number:<br>
  <input type="text" name="number">
  <br><br>
  <input type="submit" value="buy">
</form>
</body>
</html>

