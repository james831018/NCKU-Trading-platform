<DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body>

<?php
session_start();
$host="localhost";
$username="root";  
$password="";
$database="order";

mysql_connect($host,$username,$password);
mysql_select_db($database)or die( "Unable to select database");


echo "<h2>thank's for your buying</h2>";
echo "<h3>here is your order:</h3>";
echo "********************************************************************<br>";
echo "Your account is ". $_SESSION['name']."<br>";
echo "The item is $_POST[item]<br>";
echo "The price is $_POST[price]<br>";
echo "The number is $_POST[number]<br>";
echo "********************************************************************<br>";
$total=(int)($_POST['price']*$_POST['number']);
echo "<h3>So the total is: $total dollars.</h3>";


//fill into MYSQL
$sql = "INSERT INTO buy (account,name,price,number) VALUES ('$_SESSION[name]','$_POST[item]',$total,'$_POST[number]')";

if (mysql_query($sql) === TRUE) {
    echo "New record created successfully...has been added to MYSQL";
} else {
    echo "Error: " . $sql . "<br>" ;
}


?>

</body>
</html>